package ui;

// The 'Main' class initializes the 'FamilyContactManagerApp' and starts the application.
public class Main {
    public static void main(String[] args) {
        FamilyContactManagerApp app = new FamilyContactManagerApp();
        app.start();
    }
}
